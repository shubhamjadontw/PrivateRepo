import React, { useRef } from 'react'
import { useDatePickerState } from 'react-stately'
import {
    useDatePicker,
    type AriaDatePickerProps,
    type DateValue,
} from 'react-aria'
import { FormLabel, type LabelProps } from '../../shared/form-label/FormLabel'
import { DateField } from './DateField/DateField'
import { CalendarBlank } from '@phosphor-icons/react'
import { DatePickerTriggerButton } from './DatePickerTriggerButton/DatePickerTriggerButton'
import { CalendarPopover } from './CalendarPopover/CalendarPopover'
import type { PopoverProps } from '../popover/Popover'
import { CalendarDialog } from './CalendarDialog/CalendarDialog'
import { Calendar } from './Calendar/Calendar'
import type { HelperTextProps } from '../../helper/HelperTextProps'
import { Field } from '@ark-ui/react'
import clsx from 'clsx'
import getFormHelperText from '../../helper/HelperTextIcon'

interface DatePickerProps<T extends DateValue>
    extends Omit<AriaDatePickerProps<T>, 'label' | 'validationBehavior'> {
    size?: 'sm' | 'md' | 'lg'
    label?: LabelProps
    calendarIcon?: React.ReactNode
    positioning?: PopoverProps['positioning']
    helperText?: HelperTextProps
    handleValidation?: (validationDetails: ValidityState) => string | null
    validationBehavior?: 'native' | 'aria'
}

const DatePicker = <T extends DateValue>({
    size = 'md',
    label,
    calendarIcon = <CalendarBlank fill="currentColor" />,
    positioning,
    helperText,
    handleValidation,
    validationBehavior = 'native',
    ...props
}: DatePickerProps<T>) => {
    let state = useDatePickerState({...props, validationBehavior,})
    let ref = useRef(null)

    const getLabelString = () => {
        if (typeof label === 'string') {
            return label
        }

        return label?.label
    }

    let {
        groupProps,
        labelProps,
        fieldProps,
        buttonProps,
        dialogProps,
        calendarProps,
        validationDetails,
        validationErrors,
        isInvalid,
    } = useDatePicker(
        {
            ...props,
            label: getLabelString(),
            validationBehavior,
        },
        state,
        ref
    )

    const getErrorMessage = () => {
        if (!isInvalid) return null

        let message: string | null = null

        if (handleValidation && validationDetails) {
            message = handleValidation(validationDetails)
        }

        if (!message && validationErrors?.length > 0) {
            message = validationErrors[0]
        }

        return message ? { message, status: 'error' as const } : null
    }

    const errorHelperText = getErrorMessage()
    const displayHelperText = errorHelperText || helperText

    return (
        <div className="react-aria-DatePicker">
            <FormLabel
                {...labelProps}
                size={size}
                label={label}
                error={isInvalid}
            />
            <div className="divider" />
            <div
                {...groupProps}
                ref={ref}
                data-size={size}
                data-invalid={isInvalid}
                className="react-aria-Group group"
            >
                <div data-size={size} className="react-aria-DateInput">
                    <DateField size={size} ariaDateFieldProps={fieldProps} />
                </div>
                <DatePickerTriggerButton
                    size={size}
                    isInvalid={isInvalid}
                    ariaDatePickerTriggerProps={buttonProps}
                >
                    {calendarIcon}
                </DatePickerTriggerButton>
            </div>
            {state.isOpen && (
                <CalendarPopover
                    triggerRef={ref}
                    state={state}
                    positioning={positioning}
                >
                    <CalendarDialog ariaDialogProps={dialogProps}>
                        <Calendar ariaCalendarProps={calendarProps} />
                    </CalendarDialog>
                </CalendarPopover>
            )}
            {displayHelperText?.message && (
                <>
                    <div className="divider" />
                    <Field.HelperText
                        data-size={size}
                        data-status={displayHelperText.status}
                        className={clsx('ox-reset ox-FormHelperText')}
                        data-invalid={displayHelperText.status === 'error'}
                    >
                        {getFormHelperText(displayHelperText, size)}
                    </Field.HelperText>
                </>
            )}
        </div>
    )
}

export { DatePicker as CustomDatePicker }
