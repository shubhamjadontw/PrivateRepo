import React, { useRef, useState, useEffect } from 'react'
import type { DateValue } from 'react-aria'

interface YearGridProps {
    onSelect: (year: number) => void
    selectedYear?: number
    visibleYear: number
    minDate?: DateValue | null
    maxDate?: DateValue | null
}

export const YearGrid = ({
    onSelect,
    selectedYear,
    visibleYear,
    minDate,
    maxDate,
}: YearGridProps) => {
    // Calculate start year to ensure visible year is in the middle
    const startYear = visibleYear - 5
    const years = Array.from({ length: 12 }, (_, i) => startYear + i)
    const gridRef = useRef<HTMLDivElement>(null)
    
    const [focusedIndex, setFocusedIndex] = useState(() => {
        const initialIndex = years.findIndex(year => year === visibleYear)
        return initialIndex !== -1 ? initialIndex : 5
    })

    const isYearDisabled = (year: number) => {
        if (!minDate && !maxDate) return false
        if (minDate && year < minDate.year) return true
        if (maxDate && year > maxDate.year) return true
        return false
    }

    // Update focus when visible year changes
    useEffect(() => {
        // Only update focus if we're not already focused on a year in the current range
        const currentFocusedYear = years[focusedIndex]
        if (!years.includes(currentFocusedYear)) {
            const yearIndex = years.findIndex(year => year === visibleYear)
            if (yearIndex !== -1) {
                setFocusedIndex(yearIndex)
            }
        }
    }, [visibleYear, years, focusedIndex])

    useEffect(() => {
        const buttons = gridRef.current?.querySelectorAll('button')
        if (buttons?.length) {
            const button = buttons[focusedIndex] as HTMLButtonElement
            button?.focus()
        }
    }, [focusedIndex])

    const handleKeyDown = (e: React.KeyboardEvent, index: number) => {
        e.preventDefault()
        switch (e.key) {
            case 'ArrowRight': {
                let nextIndex = index
                    const nextYear = nextIndex === 11 ? years[nextIndex] + 1 : years[nextIndex + 1]
                    nextIndex = nextIndex === 11 ? 0 : nextIndex + 1
                    console.log("ArrowRight: ", nextYear, years[nextIndex])
                    if (!isYearDisabled(nextYear)) {
                        if (nextIndex === 0) {
                            gridRef.current?.dispatchEvent(new CustomEvent('yearGridNavigate', {
                                detail: 'next',
                                bubbles: true
                            }))
                        }
                        setFocusedIndex(nextIndex)
                        break
                    }
                break
            }
            case 'ArrowLeft': {
                let prevIndex = index

                    const prevYear = prevIndex === 0 ? years[prevIndex] - 1 : years[prevIndex - 1]
                    prevIndex = prevIndex === 0 ? 11 : prevIndex - 1
                    if (!isYearDisabled(prevYear)) {
                        if (prevIndex === 11) {
                            gridRef.current?.dispatchEvent(new CustomEvent('yearGridNavigate', {
                                detail: 'prev',
                                bubbles: true
                            }))
                        }
                        setFocusedIndex(prevIndex)
                        break
                    }
                break
            }
            case 'ArrowUp': {
                let upIndex = index
                    const upYear = upIndex < 4 ? years[upIndex] - 3 : years[upIndex - 4]
                    upIndex = upIndex < 4 ? upIndex + 8 : upIndex - 4
                    if (!isYearDisabled(upYear)) {
                        if (upIndex > 7) {
                            gridRef.current?.dispatchEvent(new CustomEvent('yearGridNavigate', {
                                detail: 'prev',
                                bubbles: true
                            }))
                        }
                        setFocusedIndex(upIndex)
                        break
                    }
                break
            }
            case 'ArrowDown': {
                let downIndex = index
                    const downYear = downIndex > 7 ? years[downIndex] + 3 : years[downIndex + 4]
                    downIndex = downIndex > 7 ? downIndex - 8 : downIndex + 4
                    if (!isYearDisabled(downYear)) {
                        if (downIndex < 4) {
                            gridRef.current?.dispatchEvent(new CustomEvent('yearGridNavigate', {
                                detail: 'next',
                                bubbles: true
                            }))
                        }
                        setFocusedIndex(downIndex)
                        break
                    }
                break
            }
            case 'Home':
                setFocusedIndex(0)
                break
            case 'End':
                setFocusedIndex(11)
                break
            case 'Enter':
            case ' ':
                if (!isYearDisabled(years[index])) {
                    onSelect(years[index])
                }
                break
        }
    }

    return (
        <div
            className="react-aria-YearGrid"
            ref={gridRef}
            role="grid"
            aria-label="Years"
        >
            {years.map((year, index) => {
                const disabled = isYearDisabled(year)
                return (
                    <button
                        key={year}
                        onClick={() => !disabled && onSelect(year)}
                        onKeyDown={(e) => handleKeyDown(e, index)}
                        className="react-aria-YearCell"
                        role="gridcell"
                        tabIndex={focusedIndex === index ? 0 : -1}
                        aria-selected={selectedYear === year}
                        disabled={disabled}
                        data-disabled={disabled}
                        data-selected={selectedYear === year}
                        data-focus={focusedIndex === index}
                    >
                        {year}
                    </button>
                )
            })}
        </div>
    )
}