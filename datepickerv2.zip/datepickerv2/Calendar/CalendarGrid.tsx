import { getWeeksInMonth } from '@internationalized/date'
import React from 'react'
import { useCalendarGrid, useLocale } from 'react-aria'
import type { CalendarState } from 'react-stately'
import { CalendarCell } from './CalendarCell'

interface CalendarGridProps {
    state: CalendarState
}

export const CalendarGrid = ({ state }: CalendarGridProps) => {
    let { locale } = useLocale()
    let { gridProps, headerProps, weekDays } = useCalendarGrid({}, state)

    // Get the number of weeks in the month so we can render the proper number of rows.
    //@ts-ignore
    let weeksInMonth = getWeeksInMonth(state.visibleRange.start, locale)

    return (
        <table
            {...gridProps}
            cellPadding="0"
            className="ox-reset react-aria-CalendarGrid"
        >
            <thead {...headerProps} className="ox-reset">
                <tr className="ox-reset">
                    {weekDays.map((day, index) => (
                        <th
                            className="react-aria-CalendarGrid-TableHeader"
                            key={index}
                        >
                            {day}
                        </th>
                    ))}
                </tr>
            </thead>
            <tbody>
                {[...new Array(weeksInMonth).keys()].map((weekIndex) => (
                    <tr key={weekIndex}>
                        {state.getDatesInWeek(weekIndex).map((date, i) =>
                            date ? (
                                <CalendarCell
                                    key={i}
                                    state={state}
                                    //@ts-ignore
                                    date={date}
                                />
                            ) : (
                                <td key={i} />
                            )
                        )}
                    </tr>
                ))}
            </tbody>
        </table>
    )
}
