import React, { useRef, useState, useEffect, useCallback } from 'react'
import {
    useCalendar,
    useLocale,
    type CalendarProps as AriaCalendarProps,
    type DateValue,
    type PressEvent,
} from 'react-aria'
import { useCalendarState } from 'react-stately'
import { createCalendar, CalendarDate } from '@internationalized/date'
import { CaretLeft, CaretRight } from '@phosphor-icons/react'
import { CalendarGrid } from './CalendarGrid'
import { MonthGrid } from './MonthGrid'
import { YearGrid } from './YearGrid'
import { CalendarButton } from './CalendarButton'

type GridView = 'calendar' | 'month' | 'year'

interface CalendarProps {
    ariaCalendarProps: AriaCalendarProps<DateValue>
}

export const Calendar = ({ ariaCalendarProps }: CalendarProps) => {
    const [view, setView] = useState<GridView>('calendar')
    let { locale } = useLocale()
    let state = useCalendarState({
        ...ariaCalendarProps,
        locale,
        // @ts-ignore - Ignoring type mismatch due to version differences
        createCalendar,
    })

    let ref = useRef<HTMLDivElement>(null)

    let { calendarProps, prevButtonProps, nextButtonProps, title } =
        useCalendar(ariaCalendarProps, state)

    const handleTitleClick = () => {
        if (view === 'calendar') setView('month')
        else if (view === 'month') setView('year')
    }

    const handleMonthSelect = (month: number) => {
        const currentDate = state.visibleRange.start
        const newDate = new CalendarDate(currentDate.year, month, 1)
        // @ts-ignore - Ignoring type mismatch due to version differences
        state.setFocusedDate(newDate)
        setView('calendar')
    }

    const handleYearSelect = (year: number) => {
        const currentDate = state.visibleRange.start
        const newDate = new CalendarDate(year, currentDate.month, 1)
        // @ts-ignore - Ignoring type mismatch due to version differences
        state.setFocusedDate(newDate)
        setView('month')
    }

    const handlePrevClick = useCallback((e?: PressEvent) => {
        if (view === 'calendar') {
            prevButtonProps.onPress?.(e as PressEvent)
        } else if (view === 'month') {
            const currentDate = state.visibleRange.start
            console.log('currentDate in prev click', currentDate)
            const newDate = new CalendarDate(
                currentDate.year - 1,
                currentDate.month,
                1
            )
            // @ts-ignore - Ignoring type mismatch due to version differences
            state.setFocusedDate(newDate)
        } else if (view === 'year') {
            const currentDate = state.visibleRange.start
            const newDate = new CalendarDate(
                currentDate.year - 12,
                currentDate.month,
                1
            )
            // @ts-ignore - Ignoring type mismatch due to version differences
            state.setFocusedDate(newDate)
        }
    }, [view, state, prevButtonProps])

    const handleNextClick = useCallback((e?: PressEvent) => {
        if (view === 'calendar') {
            nextButtonProps.onPress?.(e as PressEvent)
        } else if (view === 'month') {
            const currentDate = state.visibleRange.start
            const newDate = new CalendarDate(
                currentDate.year + 1,
                currentDate.month,
                1
            )
            // @ts-ignore - Ignoring type mismatch due to version differences
            state.setFocusedDate(newDate)
        } else if (view === 'year') {
            const currentDate = state.visibleRange.start
            const newDate = new CalendarDate(
                currentDate.year + 12,
                currentDate.month,
                1
            )
            // @ts-ignore - Ignoring type mismatch due to version differences
            state.setFocusedDate(newDate)
        }
    }, [view, state, nextButtonProps])

    useEffect(() => {
        const handleGridNavigate = (e: Event) => {
            const customEvent = e as CustomEvent
            console.log('Grid Navigate:', customEvent.detail)
            if (customEvent.detail === 'next') {
                handleNextClick()
            } else {
                handlePrevClick()
            }
        }

        const calendar = ref.current
        if (calendar) {
            calendar.addEventListener('monthGridNavigate', handleGridNavigate)
            calendar.addEventListener('yearGridNavigate', handleGridNavigate)
        }

        return () => {
            if (calendar) {
                calendar.removeEventListener('monthGridNavigate', handleGridNavigate)
                calendar.removeEventListener('yearGridNavigate', handleGridNavigate)
            }
        }
    }, [view, handlePrevClick, handleNextClick])

    return (
        <div {...calendarProps} ref={ref} className="react-aria-Calendar">
            <div className="react-aria-Calendar-heading">
                <CalendarButton
                    ariaButtonProps={{
                        ...prevButtonProps,
                        onPress: handlePrevClick,
                    }}
                >
                    <CaretLeft size={24} fill="currentColor" />
                </CalendarButton>
                <button
                    className="react-aria-Calendar-title"
                    onClick={handleTitleClick}
                >
                    {title}
                </button>
                <CalendarButton
                    ariaButtonProps={{
                        ...nextButtonProps,
                        onPress: handleNextClick,
                    }}
                >
                    <CaretRight size={24} fill="currentColor" />
                </CalendarButton>
            </div>
            {view === 'calendar' && <CalendarGrid state={state} />}
            {view === 'month' && (
                <MonthGrid
                    onSelect={handleMonthSelect}
                    selectedMonth={state.value?.year === state.visibleRange.start.year ? state.value?.month : undefined}
                    visibleMonth={state.visibleRange.start.month}
                    minDate={state.minValue}
                    maxDate={state.maxValue}
                    visibleYear={state.visibleRange.start.year}
                />
            )}
            {view === 'year' && (
                <YearGrid
                    onSelect={handleYearSelect}
                    selectedYear={state.value?.year}
                    visibleYear={state.visibleRange.start.year}
                    minDate={state.minValue}
                    maxDate={state.maxValue}
                />
            )}
        </div>
    )
}

