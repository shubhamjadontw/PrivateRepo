import React, { useRef, type ReactNode } from 'react'
import { useButton, type AriaButtonProps } from 'react-aria'
import { IconButton } from '../../icon-button/IconButton'

interface CalendarButtonProps {
    ariaButtonProps: AriaButtonProps
    children: ReactNode
}

export const CalendarButton = ({
    ariaButtonProps,
    children,
}: CalendarButtonProps) => {
    const ref = useRef(null)
    const { buttonProps } = useButton(ariaButtonProps, ref)

    return (
        <IconButton
            {...buttonProps}
            ref={ref}
            size="sm"
            variant="tertiary"
            color="gray"
            autoFocus={false}
        >
            {children}
        </IconButton>
    )
} 