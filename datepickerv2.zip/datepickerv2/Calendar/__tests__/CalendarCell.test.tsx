import { render, screen } from '@testing-library/react'
import { vi } from 'vitest'
import { CalendarCell } from '../CalendarCell'
import { CalendarDate } from '@internationalized/date'

// Mock the external dependencies
vi.mock('react-aria', () => ({
  useCalendarCell: () => ({
    cellProps: {},
    buttonProps: {},
    isSelected: false,
    isOutsideVisibleRange: false,
    isDisabled: false,
    formattedDate: '15',
  }),
  useFocusRing: () => ({
    focusProps: {},
    isFocusVisible: false,
  }),
  mergeProps: (...props: any[]) => Object.assign({}, ...props),
}))

vi.mock('@internationalized/date', () => ({
  CalendarDate: vi.fn(),
  isToday: () => false,
  getLocalTimeZone: () => 'UTC',
}))

describe('CalendarCell', () => {
  const mockDate = new CalendarDate(2024, 1, 15)
  const mockState = {
    value: null,
    setValue: vi.fn(),
  }

  it('renders calendar cell with default props', () => {
    render(<CalendarCell state={mockState} date={mockDate} />)
    expect(screen.getByText('15')).toBeInTheDocument()
  })

  it('renders selected cell', () => {
    vi.mocked('react-aria').useCalendarCell.mockReturnValueOnce({
      cellProps: {},
      buttonProps: {},
      isSelected: true,
      isOutsideVisibleRange: false,
      isDisabled: false,
      formattedDate: '15',
    })

    render(<CalendarCell state={mockState} date={mockDate} />)
    expect(screen.getByText('15').parentElement).toHaveAttribute('data-selected', 'true')
  })

  it('renders disabled cell', () => {
    vi.mocked('react-aria').useCalendarCell.mockReturnValueOnce({
      cellProps: {},
      buttonProps: {},
      isSelected: false,
      isOutsideVisibleRange: false,
      isDisabled: true,
      formattedDate: '15',
    })

    render(<CalendarCell state={mockState} date={mockDate} />)
    expect(screen.getByText('15').parentElement).toHaveAttribute('data-disabled', 'true')
  })

  it('hides cell outside visible range', () => {
    vi.mocked('react-aria').useCalendarCell.mockReturnValueOnce({
      cellProps: {},
      buttonProps: {},
      isSelected: false,
      isOutsideVisibleRange: true,
      isDisabled: false,
      formattedDate: '15',
    })

    render(<CalendarCell state={mockState} date={mockDate} />)
    expect(screen.getByText('15').parentElement).toHaveAttribute('hidden')
  })

  it('renders today cell', () => {
    vi.mocked('@internationalized/date').isToday.mockReturnValueOnce(true)

    render(<CalendarCell state={mockState} date={mockDate} />)
    expect(screen.getByText('15').parentElement).toHaveAttribute('data-today', 'true')
  })

  it('renders focused cell', () => {
    vi.mocked('react-aria').useFocusRing.mockReturnValueOnce({
      focusProps: {},
      isFocusVisible: true,
    })

    render(<CalendarCell state={mockState} date={mockDate} />)
    expect(screen.getByText('15').parentElement).toHaveAttribute('data-focus', 'true')
  })

  it('applies correct CSS classes', () => {
    render(<CalendarCell state={mockState} date={mockDate} />)
    expect(screen.getByRole('cell')).toHaveClass('react-aria-CalendarGridCell')
    expect(screen.getByText('15').parentElement).toHaveClass('react-aria-CalendarGridCellTrigger')
  })
}) 