import { render, screen, fireEvent } from '@testing-library/react'
import { vi } from 'vitest'
import { YearGrid } from '../YearGrid'
import { CalendarDate } from '@internationalized/date'

describe('YearGrid', () => {
  const defaultProps = {
    onSelect: vi.fn(),
    visibleYear: 2024,
  }

  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders year grid with correct range', () => {
    render(<YearGrid {...defaultProps} />)
    // Should show years from 2019 to 2030 (12 years)
    for (let year = 2019; year <= 2030; year++) {
      expect(screen.getByText(year.toString())).toBeInTheDocument()
    }
  })

  it('handles year selection', () => {
    render(<YearGrid {...defaultProps} />)
    fireEvent.click(screen.getByText('2025'))
    expect(defaultProps.onSelect).toHaveBeenCalledWith(2025)
  })

  it('highlights selected year', () => {
    render(<YearGrid {...defaultProps} selectedYear={2024} />)
    const yearButton = screen.getByText('2024')
    expect(yearButton).toHaveAttribute('data-selected', 'true')
    expect(yearButton).toHaveAttribute('aria-selected', 'true')
  })

  it('handles disabled years with minDate', () => {
    const props = {
      ...defaultProps,
      minDate: new CalendarDate(2023, 1, 1),
    }
    render(<YearGrid {...props} />)
    
    // Years before 2023 should be disabled
    expect(screen.getByText('2022')).toHaveAttribute('data-disabled', 'true')
    expect(screen.getByText('2021')).toHaveAttribute('data-disabled', 'true')
    
    // 2023 and after should be enabled
    expect(screen.getByText('2023')).not.toHaveAttribute('data-disabled')
    expect(screen.getByText('2024')).not.toHaveAttribute('data-disabled')
  })

  it('handles disabled years with maxDate', () => {
    const props = {
      ...defaultProps,
      maxDate: new CalendarDate(2025, 1, 1),
    }
    render(<YearGrid {...props} />)
    
    // Years after 2025 should be disabled
    expect(screen.getByText('2026')).toHaveAttribute('data-disabled', 'true')
    expect(screen.getByText('2027')).toHaveAttribute('data-disabled', 'true')
    
    // 2025 and before should be enabled
    expect(screen.getByText('2025')).not.toHaveAttribute('data-disabled')
    expect(screen.getByText('2024')).not.toHaveAttribute('data-disabled')
  })

  describe('Keyboard Navigation', () => {
    it('handles ArrowRight navigation', () => {
      render(<YearGrid {...defaultProps} />)
      const button2024 = screen.getByText('2024')
      button2024.focus()
      
      fireEvent.keyDown(button2024, { key: 'ArrowRight' })
      expect(screen.getByText('2025')).toHaveFocus()
    })

    it('handles ArrowLeft navigation', () => {
      render(<YearGrid {...defaultProps} />)
      const button2024 = screen.getByText('2024')
      button2024.focus()
      
      fireEvent.keyDown(button2024, { key: 'ArrowLeft' })
      expect(screen.getByText('2023')).toHaveFocus()
    })

    it('handles ArrowUp navigation', () => {
      render(<YearGrid {...defaultProps} />)
      const button2024 = screen.getByText('2024')
      button2024.focus()
      
      fireEvent.keyDown(button2024, { key: 'ArrowUp' })
      expect(screen.getByText('2020')).toHaveFocus()
    })

    it('handles ArrowDown navigation', () => {
      render(<YearGrid {...defaultProps} />)
      const button2024 = screen.getByText('2024')
      button2024.focus()
      
      fireEvent.keyDown(button2024, { key: 'ArrowDown' })
      expect(screen.getByText('2028')).toHaveFocus()
    })

    it('handles Home key navigation', () => {
      render(<YearGrid {...defaultProps} />)
      const button2024 = screen.getByText('2024')
      button2024.focus()
      
      fireEvent.keyDown(button2024, { key: 'Home' })
      expect(screen.getByText('2019')).toHaveFocus()
    })

    it('handles End key navigation', () => {
      render(<YearGrid {...defaultProps} />)
      const button2024 = screen.getByText('2024')
      button2024.focus()
      
      fireEvent.keyDown(button2024, { key: 'End' })
      expect(screen.getByText('2030')).toHaveFocus()
    })

    it('handles year navigation with ArrowRight from last year', () => {
      const mockDispatchEvent = vi.fn()
      const grid = document.createElement('div')
      grid.dispatchEvent = mockDispatchEvent

      vi.spyOn(React, 'useRef').mockReturnValue({ current: grid })

      render(<YearGrid {...defaultProps} />)
      const lastYearButton = screen.getByText('2030')
      lastYearButton.focus()
      
      fireEvent.keyDown(lastYearButton, { key: 'ArrowRight' })
      expect(mockDispatchEvent).toHaveBeenCalledWith(expect.any(CustomEvent))
      expect(mockDispatchEvent.mock.calls[0][0].detail).toBe('next')
    })

    it('handles year navigation with ArrowLeft from first year', () => {
      const mockDispatchEvent = vi.fn()
      const grid = document.createElement('div')
      grid.dispatchEvent = mockDispatchEvent

      vi.spyOn(React, 'useRef').mockReturnValue({ current: grid })

      render(<YearGrid {...defaultProps} />)
      const firstYearButton = screen.getByText('2019')
      firstYearButton.focus()
      
      fireEvent.keyDown(firstYearButton, { key: 'ArrowLeft' })
      expect(mockDispatchEvent).toHaveBeenCalledWith(expect.any(CustomEvent))
      expect(mockDispatchEvent.mock.calls[0][0].detail).toBe('prev')
    })
  })

  it('applies correct CSS classes', () => {
    render(<YearGrid {...defaultProps} />)
    expect(screen.getByRole('grid')).toHaveClass('react-aria-YearGrid')
    const yearButtons = screen.getAllByRole('gridcell')
    yearButtons.forEach(button => {
      expect(button).toHaveClass('react-aria-YearCell')
    })
  })
}) 