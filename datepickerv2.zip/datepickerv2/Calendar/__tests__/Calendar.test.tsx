import { render, screen, fireEvent } from '@testing-library/react'
import { vi } from 'vitest'
import { Calendar } from '../Calendar'
import { CalendarDate } from '@internationalized/date'

// Mock the external dependencies
vi.mock('react-aria', () => ({
  useLocale: () => ({ locale: 'en-US' }),
  useCalendar: () => ({
    calendarProps: {},
    prevButtonProps: {
      onPress: vi.fn(),
    },
    nextButtonProps: {
      onPress: vi.fn(),
    },
    title: 'January 2024',
  }),
}))

vi.mock('react-stately', () => ({
  useCalendarState: () => ({
    visibleRange: {
      start: new CalendarDate(2024, 1, 1),
    },
    value: new CalendarDate(2024, 1, 1),
    setFocusedDate: vi.fn(),
  }),
}))

vi.mock('@internationalized/date', () => ({
  createCalendar: vi.fn(),
  CalendarDate: vi.fn((year, month) => ({ year, month })),
}))

vi.mock('../CalendarGrid', () => ({
  CalendarGrid: () => <div data-testid="calendar-grid">Calendar Grid</div>,
}))

vi.mock('../MonthGrid', () => ({
  MonthGrid: () => <div data-testid="month-grid">Month Grid</div>,
}))

vi.mock('../YearGrid', () => ({
  YearGrid: () => <div data-testid="year-grid">Year Grid</div>,
}))

describe('Calendar', () => {
  const defaultProps = {
    ariaCalendarProps: {},
  }

  it('renders calendar view by default', () => {
    render(<Calendar {...defaultProps} />)
    expect(screen.getByTestId('calendar-grid')).toBeInTheDocument()
    expect(screen.queryByTestId('month-grid')).not.toBeInTheDocument()
    expect(screen.queryByTestId('year-grid')).not.toBeInTheDocument()
  })

  it('renders navigation buttons', () => {
    render(<Calendar {...defaultProps} />)
    expect(screen.getByRole('button', { name: /previous/i })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /next/i })).toBeInTheDocument()
  })

  it('renders calendar title', () => {
    render(<Calendar {...defaultProps} />)
    expect(screen.getByText('January 2024')).toBeInTheDocument()
  })

  it('switches to month view when title is clicked', () => {
    render(<Calendar {...defaultProps} />)
    fireEvent.click(screen.getByText('January 2024'))
    expect(screen.getByTestId('month-grid')).toBeInTheDocument()
    expect(screen.queryByTestId('calendar-grid')).not.toBeInTheDocument()
  })

  it('switches to year view when title is clicked in month view', () => {
    render(<Calendar {...defaultProps} />)
    const titleButton = screen.getByText('January 2024')
    fireEvent.click(titleButton) // Switch to month view
    fireEvent.click(titleButton) // Switch to year view
    expect(screen.getByTestId('year-grid')).toBeInTheDocument()
    expect(screen.queryByTestId('month-grid')).not.toBeInTheDocument()
  })

  it('handles previous button click in calendar view', () => {
    const mockPrevPress = vi.fn()
    vi.mocked('react-aria').useCalendar.mockReturnValue({
      calendarProps: {},
      prevButtonProps: {
        onPress: mockPrevPress,
      },
      nextButtonProps: {
        onPress: vi.fn(),
      },
      title: 'January 2024',
    })

    render(<Calendar {...defaultProps} />)
    fireEvent.click(screen.getByRole('button', { name: /previous/i }))
    expect(mockPrevPress).toHaveBeenCalled()
  })

  it('handles next button click in calendar view', () => {
    const mockNextPress = vi.fn()
    vi.mocked('react-aria').useCalendar.mockReturnValue({
      calendarProps: {},
      prevButtonProps: {
        onPress: vi.fn(),
      },
      nextButtonProps: {
        onPress: mockNextPress,
      },
      title: 'January 2024',
    })

    render(<Calendar {...defaultProps} />)
    fireEvent.click(screen.getByRole('button', { name: /next/i }))
    expect(mockNextPress).toHaveBeenCalled()
  })

  it('handles month grid navigation events', () => {
    render(<Calendar {...defaultProps} />)
    fireEvent.click(screen.getByText('January 2024')) // Switch to month view
    
    const calendar = screen.getByRole('group')
    const nextEvent = new CustomEvent('monthGridNavigate', { detail: 'next' })
    const prevEvent = new CustomEvent('monthGridNavigate', { detail: 'prev' })
    
    fireEvent(calendar, nextEvent)
    expect(vi.mocked('react-stately').useCalendarState().setFocusedDate).toHaveBeenCalled()
    
    fireEvent(calendar, prevEvent)
    expect(vi.mocked('react-stately').useCalendarState().setFocusedDate).toHaveBeenCalled()
  })

  it('handles year grid navigation events', () => {
    render(<Calendar {...defaultProps} />)
    const titleButton = screen.getByText('January 2024')
    fireEvent.click(titleButton) // Switch to month view
    fireEvent.click(titleButton) // Switch to year view
    
    const calendar = screen.getByRole('group')
    const nextEvent = new CustomEvent('yearGridNavigate', { detail: 'next' })
    const prevEvent = new CustomEvent('yearGridNavigate', { detail: 'prev' })
    
    fireEvent(calendar, nextEvent)
    expect(vi.mocked('react-stately').useCalendarState().setFocusedDate).toHaveBeenCalled()
    
    fireEvent(calendar, prevEvent)
    expect(vi.mocked('react-stately').useCalendarState().setFocusedDate).toHaveBeenCalled()
  })
}) 