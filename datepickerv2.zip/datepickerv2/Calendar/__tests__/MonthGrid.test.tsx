import { render, screen, fireEvent } from '@testing-library/react'
import { vi } from 'vitest'
import { MonthGrid } from '../MonthGrid'
import { CalendarDate } from '@internationalized/date'

describe('MonthGrid', () => {
  const defaultProps = {
    onSelect: vi.fn(),
    visibleMonth: 1,
    visibleYear: 2024,
  }

  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders all months', () => {
    render(<MonthGrid {...defaultProps} />)
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    months.forEach(month => {
      expect(screen.getByText(month)).toBeInTheDocument()
    })
  })

  it('handles month selection', () => {
    render(<MonthGrid {...defaultProps} />)
    fireEvent.click(screen.getByText('Mar'))
    expect(defaultProps.onSelect).toHaveBeenCalledWith(3)
  })

  it('highlights selected month', () => {
    render(<MonthGrid {...defaultProps} selectedMonth={3} />)
    const marchButton = screen.getByText('Mar')
    expect(marchButton).toHaveAttribute('data-selected', 'true')
    expect(marchButton).toHaveAttribute('aria-selected', 'true')
  })

  it('handles disabled months with minDate', () => {
    const props = {
      ...defaultProps,
      minDate: new CalendarDate(2024, 3, 1), // March 2024
    }
    render(<MonthGrid {...props} />)
    
    // January and February should be disabled
    expect(screen.getByText('Jan')).toHaveAttribute('data-disabled', 'true')
    expect(screen.getByText('Feb')).toHaveAttribute('data-disabled', 'true')
    
    // March should be enabled
    expect(screen.getByText('Mar')).not.toHaveAttribute('data-disabled')
  })

  it('handles disabled months with maxDate', () => {
    const props = {
      ...defaultProps,
      maxDate: new CalendarDate(2024, 10, 1), // October 2024
    }
    render(<MonthGrid {...props} />)
    
    // November and December should be disabled
    expect(screen.getByText('Nov')).toHaveAttribute('data-disabled', 'true')
    expect(screen.getByText('Dec')).toHaveAttribute('data-disabled', 'true')
    
    // October should be enabled
    expect(screen.getByText('Oct')).not.toHaveAttribute('data-disabled')
  })

  describe('Keyboard Navigation', () => {
    it('handles ArrowRight navigation', () => {
      render(<MonthGrid {...defaultProps} />)
      const janButton = screen.getByText('Jan')
      janButton.focus()
      
      fireEvent.keyDown(janButton, { key: 'ArrowRight' })
      expect(screen.getByText('Feb')).toHaveFocus()
    })

    it('handles ArrowLeft navigation', () => {
      render(<MonthGrid {...defaultProps} />)
      const febButton = screen.getByText('Feb')
      febButton.focus()
      
      fireEvent.keyDown(febButton, { key: 'ArrowLeft' })
      expect(screen.getByText('Jan')).toHaveFocus()
    })

    it('handles ArrowUp navigation', () => {
      render(<MonthGrid {...defaultProps} />)
      const mayButton = screen.getByText('May')
      mayButton.focus()
      
      fireEvent.keyDown(mayButton, { key: 'ArrowUp' })
      expect(screen.getByText('Jan')).toHaveFocus()
    })

    it('handles ArrowDown navigation', () => {
      render(<MonthGrid {...defaultProps} />)
      const janButton = screen.getByText('Jan')
      janButton.focus()
      
      fireEvent.keyDown(janButton, { key: 'ArrowDown' })
      expect(screen.getByText('May')).toHaveFocus()
    })

    it('handles Home key navigation', () => {
      render(<MonthGrid {...defaultProps} />)
      const juneButton = screen.getByText('Jun')
      juneButton.focus()
      
      fireEvent.keyDown(juneButton, { key: 'Home' })
      expect(screen.getByText('Jan')).toHaveFocus()
    })

    it('handles End key navigation', () => {
      render(<MonthGrid {...defaultProps} />)
      const janButton = screen.getByText('Jan')
      janButton.focus()
      
      fireEvent.keyDown(janButton, { key: 'End' })
      expect(screen.getByText('Dec')).toHaveFocus()
    })

    it('handles year navigation with ArrowRight from December', () => {
      const mockDispatchEvent = vi.fn()
      const grid = document.createElement('div')
      grid.dispatchEvent = mockDispatchEvent

      vi.spyOn(React, 'useRef').mockReturnValue({ current: grid })

      render(<MonthGrid {...defaultProps} />)
      const decButton = screen.getByText('Dec')
      decButton.focus()
      
      fireEvent.keyDown(decButton, { key: 'ArrowRight' })
      expect(mockDispatchEvent).toHaveBeenCalledWith(expect.any(CustomEvent))
      expect(mockDispatchEvent.mock.calls[0][0].detail).toBe('next')
    })

    it('handles year navigation with ArrowLeft from January', () => {
      const mockDispatchEvent = vi.fn()
      const grid = document.createElement('div')
      grid.dispatchEvent = mockDispatchEvent

      vi.spyOn(React, 'useRef').mockReturnValue({ current: grid })

      render(<MonthGrid {...defaultProps} />)
      const janButton = screen.getByText('Jan')
      janButton.focus()
      
      fireEvent.keyDown(janButton, { key: 'ArrowLeft' })
      expect(mockDispatchEvent).toHaveBeenCalledWith(expect.any(CustomEvent))
      expect(mockDispatchEvent.mock.calls[0][0].detail).toBe('prev')
    })
  })

  it('applies correct CSS classes', () => {
    render(<MonthGrid {...defaultProps} />)
    expect(screen.getByRole('grid')).toHaveClass('react-aria-MonthGrid')
    const monthButtons = screen.getAllByRole('gridcell')
    monthButtons.forEach(button => {
      expect(button).toHaveClass('react-aria-MonthCell')
    })
  })
}) 