import { render, screen, fireEvent } from '@testing-library/react'
import { vi } from 'vitest'
import { CalendarButton } from '../CalendarButton'

// Mock the external dependencies
vi.mock('react-aria', () => ({
  useButton: () => ({
    buttonProps: {
      'aria-label': 'Calendar Navigation Button',
      onClick: vi.fn(),
    },
  }),
}))

vi.mock('../../../icon-button/IconButton', () => ({
  IconButton: ({ children, ...props }: any) => (
    <button data-testid="icon-button" {...props}>
      {children}
    </button>
  ),
}))

describe('CalendarButton', () => {
  const defaultProps = {
    ariaButtonProps: {},
    children: <span data-testid="button-icon">Button Icon</span>,
  }

  it('renders button with children', () => {
    render(<CalendarButton {...defaultProps} />)
    expect(screen.getByTestId('button-icon')).toBeInTheDocument()
    expect(screen.getByText('Button Icon')).toBeInTheDocument()
  })

  it('renders as IconButton with correct props', () => {
    render(<CalendarButton {...defaultProps} />)
    const button = screen.getByTestId('icon-button')
    expect(button).toHaveAttribute('size', 'sm')
    expect(button).toHaveAttribute('variant', 'tertiary')
    expect(button).toHaveAttribute('color', 'gray')
    expect(button).toHaveAttribute('autoFocus', 'false')
  })

  it('handles button click', () => {
    const mockOnClick = vi.fn()
    vi.mocked('react-aria').useButton.mockReturnValueOnce({
      buttonProps: {
        'aria-label': 'Calendar Navigation Button',
        onClick: mockOnClick,
      },
    })

    render(<CalendarButton {...defaultProps} />)
    const button = screen.getByTestId('icon-button')
    fireEvent.click(button)
    expect(mockOnClick).toHaveBeenCalled()
  })

  it('applies ARIA properties', () => {
    const customProps = {
      ...defaultProps,
      ariaButtonProps: {
        'aria-label': 'Custom Navigation Button',
      },
    }

    vi.mocked('react-aria').useButton.mockReturnValueOnce({
      buttonProps: {
        'aria-label': 'Custom Navigation Button',
        onClick: vi.fn(),
      },
    })

    render(<CalendarButton {...customProps} />)
    const button = screen.getByTestId('icon-button')
    expect(button).toHaveAttribute('aria-label', 'Custom Navigation Button')
  })

  it('forwards ref correctly', () => {
    const ref = { current: null }
    render(<CalendarButton {...defaultProps} ref={ref} />)
    expect(screen.getByTestId('icon-button')).toBeTruthy()
  })
}) 