import { render, screen } from '@testing-library/react'
import { vi } from 'vitest'
import { CalendarGrid } from '../CalendarGrid'
import { CalendarDate } from '@internationalized/date'

// Mock the external dependencies
vi.mock('react-aria', () => ({
  useLocale: () => ({ locale: 'en-US' }),
  useCalendarGrid: () => ({
    gridProps: {},
    headerProps: {},
    weekDays: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  }),
}))

vi.mock('@internationalized/date', () => ({
  getWeeksInMonth: () => 5,
  CalendarDate: vi.fn(),
}))

vi.mock('../CalendarCell', () => ({
  CalendarCell: ({ date }: { date: any }) => (
    <td data-testid="calendar-cell">{date.day}</td>
  ),
}))

describe('CalendarGrid', () => {
  const mockState = {
    visibleRange: {
      start: new CalendarDate(2024, 1, 1),
    },
    getDatesInWeek: (weekIndex: number) => {
      // Mock returning a week of dates
      const dates = []
      for (let i = 0; i < 7; i++) {
        dates.push(new CalendarDate(2024, 1, weekIndex * 7 + i + 1))
      }
      return dates
    },
  }

  it('renders calendar grid with correct structure', () => {
    render(<CalendarGrid state={mockState} />)
    expect(screen.getByRole('table')).toBeInTheDocument()
    expect(screen.getByRole('rowgroup')).toBeInTheDocument()
  })

  it('renders weekday headers correctly', () => {
    render(<CalendarGrid state={mockState} />)
    const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
    weekdays.forEach(day => {
      expect(screen.getByText(day)).toBeInTheDocument()
    })
  })

  it('renders correct number of weeks', () => {
    render(<CalendarGrid state={mockState} />)
    const rows = screen.getAllByRole('row')
    // 1 header row + 5 weeks
    expect(rows).toHaveLength(6)
  })

  it('renders calendar cells for each date', () => {
    render(<CalendarGrid state={mockState} />)
    const cells = screen.getAllByTestId('calendar-cell')
    // 5 weeks * 7 days = 35 cells
    expect(cells).toHaveLength(35)
  })

  it('renders with custom state', () => {
    const customState = {
      ...mockState,
      visibleRange: {
        start: new CalendarDate(2024, 2, 1), // February
      },
      getDatesInWeek: (weekIndex: number) => {
        const dates = []
        for (let i = 0; i < 7; i++) {
          dates.push(new CalendarDate(2024, 2, weekIndex * 7 + i + 1))
        }
        return dates
      },
    }

    render(<CalendarGrid state={customState} />)
    expect(screen.getAllByTestId('calendar-cell')).toHaveLength(35)
  })

  it('handles empty dates in week', () => {
    const stateWithEmptyDates = {
      ...mockState,
      getDatesInWeek: (weekIndex: number) => {
        // Return some null dates to simulate empty cells
        return [null, null, ...Array(5).fill(new CalendarDate(2024, 1, 1))]
      },
    }

    render(<CalendarGrid state={stateWithEmptyDates} />)
    const cells = screen.getAllByTestId('calendar-cell')
    // Should render only non-null dates (5 per week * 5 weeks)
    expect(cells).toHaveLength(25)
  })

  it('applies correct CSS classes', () => {
    render(<CalendarGrid state={mockState} />)
    expect(screen.getByRole('table')).toHaveClass('ox-reset', 'react-aria-CalendarGrid')
    expect(screen.getByRole('rowgroup')).toHaveClass('ox-reset')
  })
}) 