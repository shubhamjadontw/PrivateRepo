import React, { useRef, useState, useEffect } from 'react'
import type { DateValue } from 'react-aria'

interface MonthGridProps {
    onSelect: (month: number) => void
    selectedMonth?: number
    visibleMonth: number
    minDate?: DateValue | null
    maxDate?: DateValue | null
    visibleYear: number
}

export const MonthGrid = ({
    onSelect,
    selectedMonth,
    visibleMonth,
    minDate,
    maxDate,
    visibleYear,
}: MonthGridProps) => {
    const months = [
        'Jan', 'Feb', 'Mar', 'Apr',
        'May', 'Jun', 'Jul', 'Aug',
        'Sep', 'Oct', 'Nov', 'Dec'
    ]
    const gridRef = useRef<HTMLDivElement>(null)
    const [focusedIndex, setFocusedIndex] = useState(visibleMonth - 1)

    const isMonthDisabled = (monthIndex: number, year: number = visibleYear) => {
        if (!minDate && !maxDate) return false
        
        const month = monthIndex + 1
        if (minDate) {
            if (year < minDate.year) return true
            if (year === minDate.year && month < minDate.month) return true
        }
        if (maxDate) {
            if (year > maxDate.year) return true
            if (year === maxDate.year && month > maxDate.month) return true
        }
        return false
    }

    // Update focus when visible month changes
    useEffect(() => {
        setFocusedIndex(visibleMonth - 1)
    }, [visibleMonth])

    useEffect(() => {
        const buttons = gridRef.current?.querySelectorAll('button')
        if (buttons?.length) {
            const button = buttons[focusedIndex] as HTMLButtonElement
            button?.focus()
        }
    }, [focusedIndex])

    const handleKeyDown = (e: React.KeyboardEvent, index: number) => {
        e.preventDefault()
        switch (e.key) {
            case 'ArrowRight': {
                if (index === 11) {
                    // Check if we can move to next year's January
                    if (!isMonthDisabled(0, visibleYear + 1)) {
                        gridRef.current?.dispatchEvent(new CustomEvent('monthGridNavigate', {
                            detail: 'next',
                            bubbles: true
                        }))
                        setFocusedIndex(0)
                    }
                } else {
                    // Check next month in current year
                    const nextIndex = index + 1
                    if (!isMonthDisabled(nextIndex)) {
                        setFocusedIndex(nextIndex)
                    }
                }
                break
            }
            case 'ArrowLeft': {
                if (index === 0) {
                    // Check if we can move to previous year's December
                    if (!isMonthDisabled(11, visibleYear - 1)) {
                        gridRef.current?.dispatchEvent(new CustomEvent('monthGridNavigate', {
                            detail: 'prev',
                            bubbles: true
                        }))
                        setFocusedIndex(11)
                    }
                } else {
                    // Check previous month in current year
                    const prevIndex = index - 1
                    if (!isMonthDisabled(prevIndex)) {
                        setFocusedIndex(prevIndex)
                    }
                }
                break
            }
            case 'ArrowUp': {
                if (index < 4) {
                    // Check if we can move to previous year's same column
                    const targetIndex = index + 8
                    if (!isMonthDisabled(targetIndex, visibleYear - 1)) {
                        gridRef.current?.dispatchEvent(new CustomEvent('monthGridNavigate', {
                            detail: 'prev',
                            bubbles: true
                        }))
                        setFocusedIndex(targetIndex)
                    }
                } else {
                    // Check previous row in current year
                    const upIndex = index - 4
                    if (!isMonthDisabled(upIndex)) {
                        setFocusedIndex(upIndex)
                    }
                }
                break
            }
            case 'ArrowDown': {
                if (index > 7) {
                    // Check if we can move to next year's same column
                    const targetIndex = index - 8
                    if (!isMonthDisabled(targetIndex, visibleYear + 1)) {
                        gridRef.current?.dispatchEvent(new CustomEvent('monthGridNavigate', {
                            detail: 'next',
                            bubbles: true
                        }))
                        setFocusedIndex(targetIndex)
                    }
                } else {
                    // Check next row in current year
                    const downIndex = index + 4
                    if (!isMonthDisabled(downIndex)) {
                        setFocusedIndex(downIndex)
                    }
                }
                break
            }
            case 'Home': {
                // Find first enabled month in current year
                let firstIndex = 0
                while (firstIndex < 12 && isMonthDisabled(firstIndex)) {
                    firstIndex++
                }
                if (firstIndex < 12) {
                    setFocusedIndex(firstIndex)
                }
                break
            }
            case 'End': {
                // Find last enabled month in current year
                let lastIndex = 11
                while (lastIndex >= 0 && isMonthDisabled(lastIndex)) {
                    lastIndex--
                }
                if (lastIndex >= 0) {
                    setFocusedIndex(lastIndex)
                }
                break
            }
            case 'Enter':
            case ' ':
                if (!isMonthDisabled(index)) {
                    onSelect(index + 1)
                }
                break
        }
    }

    return (
        <div
            className="react-aria-MonthGrid"
            ref={gridRef}
            role="grid"
            aria-label="Months"
        >
            {months.map((month, index) => {
                const disabled = isMonthDisabled(index)
                return (
                    <button
                        key={month}
                        onClick={() => !disabled && onSelect(index + 1)}
                        onKeyDown={(e) => handleKeyDown(e, index)}
                        className="react-aria-MonthCell"
                        role="gridcell"
                        tabIndex={focusedIndex === index ? 0 : -1}
                        aria-selected={selectedMonth === index + 1}
                        disabled={disabled}
                        data-disabled={disabled}
                        data-selected={selectedMonth === index + 1}
                        data-focus={focusedIndex === index}
                    >
                        {month}
                    </button>
                )
            })}
        </div>
    )
}