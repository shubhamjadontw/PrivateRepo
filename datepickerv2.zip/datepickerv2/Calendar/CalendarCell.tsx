import React, { useRef } from 'react'
import { useCalendarCell, useFocusRing, mergeProps } from 'react-aria'
import {
    CalendarDate,
    isToday,
    getLocalTimeZone,
} from '@internationalized/date'
import type { CalendarState } from 'react-stately'

interface CalendarCellProps {
    state: CalendarState
    date: CalendarDate
}

export function CalendarCell({ state, date }: CalendarCellProps) {
    const ref = useRef(null)
    const {
        cellProps,
        buttonProps,
        isSelected,
        isOutsideVisibleRange,
        isDisabled,
        formattedDate,
        //@ts-ignore
    } = useCalendarCell({ date }, state, ref)

    const isTodayDate = isToday(date, getLocalTimeZone())

    const { focusProps, isFocusVisible } = useFocusRing()

    return (
        <td {...cellProps} className="react-aria-CalendarGridCell">
            <div
                {...mergeProps(buttonProps, focusProps)}
                ref={ref}
                hidden={isOutsideVisibleRange}
                className="react-aria-CalendarGridCellTrigger"
                data-today={isTodayDate}
                data-focus={isFocusVisible}
                data-selected={isSelected}
                data-disabled={isDisabled}
            >
                {formattedDate}
            </div>
        </td>
    )
}
