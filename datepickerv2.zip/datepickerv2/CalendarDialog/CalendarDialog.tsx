import React, { useRef, type ReactNode } from 'react'
import { useDialog, type AriaDialogProps } from 'react-aria'

interface CalendarDialog {
    ariaDialogProps: AriaDialogProps
    children: ReactNode
}
export const CalendarDialog = ({
    ariaDialogProps,
    children,
}: CalendarDialog) => {
    let ref = useRef(null)
    let { dialogProps } = useDialog(ariaDialogProps, ref)

    return (
        <div {...dialogProps} ref={ref} className="react-aria-CalendarDialog">
            {children}
        </div>
    )
}
