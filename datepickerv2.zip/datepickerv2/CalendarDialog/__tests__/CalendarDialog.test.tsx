import { render, screen } from '@testing-library/react'
import { vi } from 'vitest'
import { CalendarDialog } from '../CalendarDialog'

// Mock the external dependencies
vi.mock('react-aria', () => ({
  useDialog: () => ({
    dialogProps: {
      'aria-label': 'Calendar Dialog',
    },
  }),
}))

describe('CalendarDialog', () => {
  const defaultProps = {
    ariaDialogProps: {},
    children: <div data-testid="calendar-content">Calendar Content</div>,
  }

  it('renders dialog with children', () => {
    render(<CalendarDialog {...defaultProps} />)
    expect(screen.getByTestId('calendar-content')).toBeInTheDocument()
    expect(screen.getByText('Calendar Content')).toBeInTheDocument()
  })

  it('applies ARIA properties from useDialog', () => {
    render(<CalendarDialog {...defaultProps} />)
    const dialog = screen.getByRole('generic')
    expect(dialog).toHaveAttribute('aria-label', 'Calendar Dialog')
  })

  it('applies correct CSS class', () => {
    render(<CalendarDialog {...defaultProps} />)
    const dialog = screen.getByRole('generic')
    expect(dialog).toHaveClass('react-aria-CalendarDialog')
  })

  it('renders with custom aria props', () => {
    const customProps = {
      ...defaultProps,
      ariaDialogProps: {
        'aria-label': 'Custom Calendar Dialog',
      },
    }

    vi.mocked('react-aria').useDialog.mockReturnValueOnce({
      dialogProps: {
        'aria-label': 'Custom Calendar Dialog',
      },
    })

    render(<CalendarDialog {...customProps} />)
    const dialog = screen.getByRole('generic')
    expect(dialog).toHaveAttribute('aria-label', 'Custom Calendar Dialog')
  })

  it('renders multiple children', () => {
    const multipleChildren = {
      ...defaultProps,
      children: (
        <>
          <div data-testid="child-1">Child 1</div>
          <div data-testid="child-2">Child 2</div>
        </>
      ),
    }

    render(<CalendarDialog {...multipleChildren} />)
    expect(screen.getByTestId('child-1')).toBeInTheDocument()
    expect(screen.getByTestId('child-2')).toBeInTheDocument()
  })
}) 