import { render, screen, fireEvent } from '@testing-library/react'
import { vi } from 'vitest'
import { CustomDatePicker } from '../Datepicker'
import { CalendarBlank } from '@phosphor-icons/react'

// Mock the external dependencies
vi.mock('react-stately', () => ({
  useDatePickerState: () => ({
    isOpen: false,
    setOpen: vi.fn(),
  })
}))

vi.mock('react-aria', () => ({
  useDatePicker: () => ({
    groupProps: {},
    labelProps: {},
    fieldProps: {},
    buttonProps: {},
    dialogProps: {},
    calendarProps: {},
    validationDetails: {},
    validationErrors: [],
    isInvalid: false,
  })
}))

vi.mock('@ark-ui/react', () => ({
  Field: {
    HelperText: ({ children, ...props }: any) => (
      <div data-testid="helper-text" {...props}>
        {children}
      </div>
    ),
  },
}))

describe('CustomDatePicker', () => {
  it('renders with default props', () => {
    render(<CustomDatePicker />)
    expect(screen.getByRole('group')).toBeInTheDocument()
  })

  it('renders with custom size', () => {
    render(<CustomDatePicker size="sm" />)
    const group = screen.getByRole('group')
    expect(group.getAttribute('data-size')).toBe('sm')
  })

  it('renders with label', () => {
    render(<CustomDatePicker label="Test Label" />)
    expect(screen.getByText('Test Label')).toBeInTheDocument()
  })

  it('renders with custom calendar icon', () => {
    const customIcon = <CalendarBlank data-testid="custom-icon" />
    render(<CustomDatePicker calendarIcon={customIcon} />)
    expect(screen.getByTestId('custom-icon')).toBeInTheDocument()
  })

  it('renders with helper text', () => {
    render(
      <CustomDatePicker
        helperText={{ message: 'Helper message', status: 'info' }}
      />
    )
    expect(screen.getByText('Helper message')).toBeInTheDocument()
  })

  it('renders with error state', () => {
    vi.mocked('react-aria').useDatePicker.mockReturnValueOnce({
      ...vi.mocked('react-aria').useDatePicker(),
      isInvalid: true,
      validationErrors: ['Error message'],
    })

    render(<CustomDatePicker />)
    const group = screen.getByRole('group')
    expect(group.getAttribute('data-invalid')).toBe('true')
  })

  it('handles custom validation', () => {
    const handleValidation = vi.fn().mockReturnValue('Custom error')
    vi.mocked('react-aria').useDatePicker.mockReturnValueOnce({
      ...vi.mocked('react-aria').useDatePicker(),
      isInvalid: true,
      validationDetails: { valid: false },
    })

    render(<CustomDatePicker handleValidation={handleValidation} />)
    expect(handleValidation).toHaveBeenCalled()
    expect(screen.getByText('Custom error')).toBeInTheDocument()
  })

  it('renders with different validation behavior', () => {
    render(<CustomDatePicker validationBehavior="aria" />)
    // Verify that the validation behavior is passed to useDatePickerState
    expect(vi.mocked('react-stately').useDatePickerState).toHaveBeenCalledWith(
      expect.objectContaining({ validationBehavior: 'aria' })
    )
  })

  it('renders with custom positioning', () => {
    render(<CustomDatePicker positioning={{ placement: 'bottom' }} />)
    // The positioning prop will be passed to CalendarPopover when the picker is open
    expect(screen.getByRole('group')).toBeInTheDocument()
  })
}) 