import React from 'react'
import { type PopoverProps } from '../../popover/Popover.js'
import type { DatePickerState } from 'react-stately'
import { usePopover, DismissButton, Overlay, type Placement } from 'react-aria'

interface CalendarPopoverProps {
    state: DatePickerState
    children: React.ReactNode
    triggerRef: React.RefObject<HTMLElement>
    positioning?: PopoverProps['positioning']
}

const getPopoverPosition = (
    positioning?: PopoverProps['positioning']
): Placement => {
    if (!positioning?.placement) return 'bottom start'

    // Convert placement string to react-aria format
    const placement = positioning.placement
    if (placement === 'bottom-start') return 'bottom start'
    if (placement === 'bottom-end') return 'bottom right'
    if (placement === 'top-start') return 'top start'
    if (placement === 'top-end') return 'top end'
    if (placement === 'left-start') return 'left top'
    if (placement === 'left-end') return 'left bottom'
    if (placement === 'right-start') return 'right top'
    if (placement === 'right-end') return 'right bottom'
    return placement
}

export const CalendarPopover = (props: CalendarPopoverProps) => {
    let ref = React.useRef(null)
    let { state, children, positioning } = props

    const placement = getPopoverPosition(positioning)

    let { popoverProps, underlayProps } = usePopover(
        {
            ...props,
            popoverRef: ref,
            placement,
        },
        state
    )

    return (
        <Overlay>
            <div
                {...underlayProps}
                className="react-aria-CalendarPopover-underlay"
            />
            <div
                {...popoverProps}
                ref={ref}
                className="react-aria-CalendarPopover"
                data-placement={placement}
            >
                <DismissButton onDismiss={state.close} />
                {children}
                <DismissButton onDismiss={state.close} />
            </div>
        </Overlay>
    )
}
