import { render, screen } from '@testing-library/react'
import { vi } from 'vitest'
import { CalendarPopover } from '../CalendarPopover'

// Mock the external dependencies
vi.mock('react-aria', () => ({
  usePopover: () => ({
    popoverProps: {
      'aria-label': 'Calendar Popover',
    },
    underlayProps: {},
  }),
  DismissButton: ({ onDismiss }: { onDismiss: () => void }) => (
    <button onClick={onDismiss} data-testid="dismiss-button">
      Dismiss
    </button>
  ),
  Overlay: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="overlay">{children}</div>
  ),
}))

describe('CalendarPopover', () => {
  const mockState = {
    close: vi.fn(),
  }

  const defaultProps = {
    state: mockState,
    children: <div data-testid="popover-content">Popover Content</div>,
    triggerRef: { current: null },
  }

  it('renders popover with children', () => {
    render(<CalendarPopover {...defaultProps} />)
    expect(screen.getByTestId('popover-content')).toBeInTheDocument()
    expect(screen.getByText('Popover Content')).toBeInTheDocument()
  })

  it('renders overlay and underlay', () => {
    render(<CalendarPopover {...defaultProps} />)
    expect(screen.getByTestId('overlay')).toBeInTheDocument()
    expect(screen.getByClassName('react-aria-CalendarPopover-underlay')).toBeInTheDocument()
  })

  it('renders dismiss buttons', () => {
    render(<CalendarPopover {...defaultProps} />)
    const dismissButtons = screen.getAllByTestId('dismiss-button')
    expect(dismissButtons).toHaveLength(2)
  })

  it('applies correct CSS classes', () => {
    render(<CalendarPopover {...defaultProps} />)
    expect(screen.getByClassName('react-aria-CalendarPopover')).toBeInTheDocument()
  })

  it('handles default placement', () => {
    render(<CalendarPopover {...defaultProps} />)
    const popover = screen.getByClassName('react-aria-CalendarPopover')
    expect(popover).toHaveAttribute('data-placement', 'bottom start')
  })

  it('handles custom placement', () => {
    const propsWithPlacement = {
      ...defaultProps,
      positioning: {
        placement: 'top-start',
      },
    }

    render(<CalendarPopover {...propsWithPlacement} />)
    const popover = screen.getByClassName('react-aria-CalendarPopover')
    expect(popover).toHaveAttribute('data-placement', 'top start')
  })

  it('converts all placement variations correctly', () => {
    const placements = [
      { input: 'bottom-start', expected: 'bottom start' },
      { input: 'bottom-end', expected: 'bottom right' },
      { input: 'top-start', expected: 'top start' },
      { input: 'top-end', expected: 'top end' },
      { input: 'left-start', expected: 'left top' },
      { input: 'left-end', expected: 'left bottom' },
      { input: 'right-start', expected: 'right top' },
      { input: 'right-end', expected: 'right bottom' },
    ]

    placements.forEach(({ input, expected }) => {
      const propsWithPlacement = {
        ...defaultProps,
        positioning: {
          placement: input,
        },
      }

      render(<CalendarPopover {...propsWithPlacement} />)
      const popover = screen.getByClassName('react-aria-CalendarPopover')
      expect(popover).toHaveAttribute('data-placement', expected)
      cleanup()
    })
  })

  it('calls close function when dismiss button is clicked', () => {
    render(<CalendarPopover {...defaultProps} />)
    const dismissButtons = screen.getAllByTestId('dismiss-button')
    dismissButtons.forEach(button => {
      fireEvent.click(button)
      expect(mockState.close).toHaveBeenCalled()
    })
  })
}) 