import React, { useRef } from 'react'
import {
    useDateField,
    useDateSegment,
    useLocale,
    type AriaDatePickerProps,
    type DateValue,
} from 'react-aria'
import {
    useDateFieldState,
    type DateFieldState,
    type DateSegment,
} from 'react-stately'
import { createCalendar } from '@internationalized/date'
import clsx from 'clsx'

interface DateFieldProps {
    size?: 'sm' | 'md' | 'lg'
    ariaDateFieldProps: AriaDatePickerProps<DateValue>
}

export const DateField = ({ size, ariaDateFieldProps }: DateFieldProps) => {
    let { locale } = useLocale()
    let state = useDateFieldState({
        ...ariaDateFieldProps,
        locale,
        // @ts-ignore
        createCalendar,
    })

    let ref = useRef(null)
    const inputRef = useRef(null);

    let { fieldProps, inputProps } = useDateField({...ariaDateFieldProps, inputRef}, state, ref)

    const getFontSizeClass = () => {
        switch (size) {
            case 'sm':
                return 'ox-fz-sm'
            case 'lg':
                return 'ox-fz-lg'
            default:
                return 'ox-fz-md'
        }
    }

    const fontSizeClass = getFontSizeClass()

    return (
        <>
            <div
                {...fieldProps}
                ref={ref}
                className={clsx('react-aria-DateField', fontSizeClass)}
                data-size={size}
            >
                {state.segments.map((segment, i) => (
                    <DateSegment key={i} segment={segment} state={state} />
                ))}
            </div>
            <input {...inputProps} ref={inputRef} />
        </>
    )
}

interface DateSegmentProps {
    segment: DateSegment
    state: DateFieldState
}

function DateSegment({ segment, state }: DateSegmentProps) {
    let ref = useRef(null)
    let { segmentProps } = useDateSegment(segment, state, ref)

    return (
        <div
            {...segmentProps}
            ref={ref}
            style={{
                ...segmentProps.style,
                minWidth:
                    (segment.maxValue != null &&
                        String(segment.maxValue).length + 'ch') ||
                    undefined,
            }}
            className={clsx(
                'react-aria-DateSegment',
                !segment.isEditable && 'seperator'
            )}
            data-is-placeholder={segment.isPlaceholder}
        >
            {segment.text}
        </div>
    )
}
