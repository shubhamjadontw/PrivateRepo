import { render, screen } from '@testing-library/react'
import { vi } from 'vitest'
import { DateField } from '../DateField'

// Mock the external dependencies
vi.mock('react-aria', () => ({
  useLocale: () => ({ locale: 'en-US' }),
  useDateField: () => ({
    fieldProps: {},
    inputProps: {},
  }),
  useDateSegment: () => ({
    segmentProps: {
      style: {},
    },
  }),
}))

vi.mock('react-stately', () => ({
  useDateFieldState: () => ({
    segments: [
      {
        type: 'month',
        text: '01',
        isPlaceholder: false,
        isEditable: true,
      },
      {
        type: 'literal',
        text: '/',
        isPlaceholder: false,
        isEditable: false,
      },
      {
        type: 'day',
        text: '01',
        isPlaceholder: false,
        isEditable: true,
      },
      {
        type: 'literal',
        text: '/',
        isPlaceholder: false,
        isEditable: false,
      },
      {
        type: 'year',
        text: '2024',
        isPlaceholder: false,
        isEditable: true,
      },
    ],
  }),
}))

vi.mock('@internationalized/date', () => ({
  createCalendar: vi.fn(),
}))

describe('DateField', () => {
  const defaultProps = {
    ariaDateFieldProps: {},
  }

  it('renders with default props', () => {
    render(<DateField {...defaultProps} />)
    expect(screen.getByText('01')).toBeInTheDocument()
    expect(screen.getByText('2024')).toBeInTheDocument()
  })

  it('renders with small size', () => {
    render(<DateField {...defaultProps} size="sm" />)
    const dateField = screen.getByRole('group')
    expect(dateField.getAttribute('data-size')).toBe('sm')
    expect(dateField).toHaveClass('ox-fz-sm')
  })

  it('renders with medium size', () => {
    render(<DateField {...defaultProps} size="md" />)
    const dateField = screen.getByRole('group')
    expect(dateField.getAttribute('data-size')).toBe('md')
    expect(dateField).toHaveClass('ox-fz-md')
  })

  it('renders with large size', () => {
    render(<DateField {...defaultProps} size="lg" />)
    const dateField = screen.getByRole('group')
    expect(dateField.getAttribute('data-size')).toBe('lg')
    expect(dateField).toHaveClass('ox-fz-lg')
  })

  it('renders date segments correctly', () => {
    render(<DateField {...defaultProps} />)
    const segments = screen.getAllByRole('spinbutton')
    expect(segments).toHaveLength(3) // month, day, year
  })

  it('renders separator segments correctly', () => {
    render(<DateField {...defaultProps} />)
    const separators = screen.getAllByText('/')
    expect(separators).toHaveLength(2)
    separators.forEach(separator => {
      expect(separator.parentElement).toHaveClass('seperator')
    })
  })

  it('renders placeholder segments correctly', () => {
    vi.mocked('react-stately').useDateFieldState.mockReturnValueOnce({
      segments: [
        {
          type: 'month',
          text: 'mm',
          isPlaceholder: true,
          isEditable: true,
        },
      ],
    })

    render(<DateField {...defaultProps} />)
    const placeholder = screen.getByText('mm')
    expect(placeholder.parentElement).toHaveAttribute('data-is-placeholder', 'true')
  })
}) 