import { render, screen, fireEvent } from '@testing-library/react'
import { vi } from 'vitest'
import { DatePickerTriggerButton } from '../DatePickerTriggerButton'

// Mock the external dependencies
vi.mock('react-aria', () => ({
  useButton: () => ({
    buttonProps: {
      'aria-label': 'Calendar Button',
      onClick: vi.fn(),
    },
  }),
}))

describe('DatePickerTriggerButton', () => {
  const defaultProps = {
    isInvalid: false,
    ariaDatePickerTriggerProps: {},
    children: <span data-testid="calendar-icon">Calendar Icon</span>,
  }

  it('renders button with children', () => {
    render(<DatePickerTriggerButton {...defaultProps} />)
    expect(screen.getByTestId('calendar-icon')).toBeInTheDocument()
    expect(screen.getByText('Calendar Icon')).toBeInTheDocument()
  })

  it('applies correct CSS classes', () => {
    render(<DatePickerTriggerButton {...defaultProps} />)
    const button = screen.getByRole('button')
    expect(button).toHaveClass('ox-reset', 'react-aria-DatePickerTrigger', 'ox-FormIcon')
  })

  it('handles small size', () => {
    render(<DatePickerTriggerButton {...defaultProps} size="sm" />)
    const button = screen.getByRole('button')
    expect(button).toHaveAttribute('data-size', 'sm')
  })

  it('handles medium size', () => {
    render(<DatePickerTriggerButton {...defaultProps} size="md" />)
    const button = screen.getByRole('button')
    expect(button).toHaveAttribute('data-size', 'md')
  })

  it('handles large size', () => {
    render(<DatePickerTriggerButton {...defaultProps} size="lg" />)
    const button = screen.getByRole('button')
    expect(button).toHaveAttribute('data-size', 'lg')
  })

  it('handles invalid state', () => {
    render(<DatePickerTriggerButton {...defaultProps} isInvalid={true} />)
    const button = screen.getByRole('button')
    expect(button).toHaveAttribute('data-error', 'true')
  })

  it('handles button click', () => {
    const mockOnClick = vi.fn()
    vi.mocked('react-aria').useButton.mockReturnValueOnce({
      buttonProps: {
        'aria-label': 'Calendar Button',
        onClick: mockOnClick,
      },
    })

    render(<DatePickerTriggerButton {...defaultProps} />)
    const button = screen.getByRole('button')
    fireEvent.click(button)
    expect(mockOnClick).toHaveBeenCalled()
  })

  it('applies ARIA properties', () => {
    const customProps = {
      ...defaultProps,
      ariaDatePickerTriggerProps: {
        'aria-label': 'Custom Calendar Button',
      },
    }

    vi.mocked('react-aria').useButton.mockReturnValueOnce({
      buttonProps: {
        'aria-label': 'Custom Calendar Button',
        onClick: vi.fn(),
      },
    })

    render(<DatePickerTriggerButton {...customProps} />)
    const button = screen.getByRole('button')
    expect(button).toHaveAttribute('aria-label', 'Custom Calendar Button')
  })
}) 