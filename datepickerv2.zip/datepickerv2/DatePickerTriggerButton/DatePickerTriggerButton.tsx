import React, { useRef } from 'react'
import { useButton, type AriaButtonProps } from 'react-aria'

interface DatePickerTriggerButtonProps {
    size?: 'sm' | 'md' | 'lg'
    isInvalid: boolean
    ariaDatePickerTriggerProps: AriaButtonProps
    children: React.ReactNode
}

export function DatePickerTriggerButton({
    size,
    isInvalid,
    ariaDatePickerTriggerProps,
    children,
}: DatePickerTriggerButtonProps) {
    let ref = useRef(null)
    let { buttonProps } = useButton(ariaDatePickerTriggerProps, ref)

    return (
        <button
            {...buttonProps}
            ref={ref}
            className="ox-reset react-aria-DatePickerTrigger ox-FormIcon"
            data-error={isInvalid}
            data-size={size}
        >
            {children}
        </button>
    )
}
